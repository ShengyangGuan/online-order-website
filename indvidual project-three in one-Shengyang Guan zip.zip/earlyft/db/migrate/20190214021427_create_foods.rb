class CreateFoods < ActiveRecord::Migration[5.2]
  def change
    create_table :foods do |t|
      t.integer :foodid
      t.string :name
      t.text :description
      t.float :price
      t.string :cooktime
      t.integer :storeid

      t.timestamps
    end
  end
end
