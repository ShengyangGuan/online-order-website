class CreateReceipts < ActiveRecord::Migration[5.2]
  def change
    create_table :receipts do |t|
      t.integer :userid
      t.integer :orderid
      t.datetime :donetime
      t.float :tips

      t.timestamps
    end
  end
end
