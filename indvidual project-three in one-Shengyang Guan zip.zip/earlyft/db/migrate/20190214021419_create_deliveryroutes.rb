class CreateDeliveryroutes < ActiveRecord::Migration[5.2]
  def change
    create_table :deliveryroutes do |t|
      t.string :beginaddress
      t.string :endaddress
      t.string :assumingtime
      t.string :Transtime
      t.integer :orderid

      t.timestamps
    end
  end
end
