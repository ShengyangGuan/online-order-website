class CreateOrders < ActiveRecord::Migration[5.2]
  def change
    create_table :orders do |t|
      t.string :userid
      t.string :orderid
      t.float :price
      t.datetime :ordertime
      t.string :storeid
      t.integer :EMPid

      t.timestamps
    end
  end
end
