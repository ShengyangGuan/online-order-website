class CreateCustomers < ActiveRecord::Migration[5.2]
  def change
    create_table :customers do |t|
      t.integer :userid
      t.string :firstname
      t.string :lastname
      t.string :email
      t.string :phone
      t.string :address1
      t.string :city
      t.string :state
      t.string :zip
      t.text :addlnotes

      t.timestamps
    end
  end
end
