# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)



# Customer.create(userid:"0001234", firstname:"Ray", lastname:"Aleen", email:"rap@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"a123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"0001235", firstname:"Rayeen", lastname:"Aleen", email:"rap1@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"b123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"0001236", firstname:"Ray", lastname:"Aleen234", email:"rap2@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"c123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"0001237", firstname:"Rayan", lastname:"Aleen", email:"rap3@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"d123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"0001238", firstname:"LILI", lastname:"Aleen", email:"rap4@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"e123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"0001239", firstname:"Ray", lastname:"kumail", email:"rap78@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"f123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"00012310", firstname:"tom", lastname:"lee", email:"rap9@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"g123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"00012340", firstname:"kki", lastname:"li", email:"rap99@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"h123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"00012350", firstname:"oo", lastname:"Aleen", email:"rap66@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"i123", password:"password123", password_confirmation:"password123")
# Customer.create(userid:"00012332", firstname:"xx", lastname:"Aleen", email:"rap76@gg.com",phone:"3127214567", address1:"1 E State st", city:"Chicago",state:"IL", zip:"60601",username:"j123", password:"password123", password_confirmation:"password123")



# Employee.create(firstname:"michal", lastname:"jordan", email:"mj@gg.com", phone:"7732114567",EMPid:"00213456")
# Employee.create(firstname:"nichal", lastname:"qordan", email:"mjj@gg.com", phone:"7732114457",EMPid:"00213457")
# Employee.create(firstname:"bichal", lastname:"wordan", email:"mkj@gg.com", phone:"7732114127",EMPid:"00213459")
# Employee.create(firstname:"vichal", lastname:"eordan", email:"mkj@gg.com", phone:"7732114367",EMPid:"00213412")
# Employee.create(firstname:"cichal", lastname:"rordan", email:"mfj@gg.com", phone:"7732114847",EMPid:"00213432")
# Employee.create(firstname:"xichal", lastname:"tordan", email:"mjd@gg.com", phone:"7732114647",EMPid:"00213465")
# Employee.create(firstname:"zichal", lastname:"yordan", email:"mja@gg.com", phone:"7732114697",EMPid:"00213474")
# Employee.create(firstname:"aichal", lastname:"uordan", email:"mjq@gg.com", phone:"7732114757",EMPid:"00213485")
# Employee.create(firstname:"dichal", lastname:"iordan", email:"mjw@gg.com", phone:"7732114617",EMPid:"00213496")
# Employee.create(firstname:"gichal", lastname:"pordan", email:"mjrr@gg.com", phone:"7732116367",EMPid:"00213546")


# Food.create(foodid:"1",name:"Chicken",description:"raw!!!",price:"10.0",cooktime:"20min",storeid:"741")
# Food.create(foodid:"12",name:"beef",description:"better than mcdonald",price:"100.0",cooktime:"20min",storeid:"741")
# Food.create(foodid:"13",name:"kongpao Chicken",description:"cooked",price:"20.0",cooktime:"20min",storeid:"741")
# Food.create(foodid:"14",name:"Chicken feet",description:"spicy",price:"30.9",cooktime:"20min",storeid:"741")
# Food.create(foodid:"15",name:"steak",description:"ruby",price:"40.2",cooktime:"20min",storeid:"741")
# Food.create(foodid:"16",name:"tucky",description:"good to play",price:"63.0",cooktime:"20min",storeid:"741")
# Food.create(foodid:"17",name:"hujianren",description:"good for guangdongese",price:"999.0",cooktime:"20min",storeid:"741")
# Food.create(foodid:"18",name:"cow",description:"make with milk",price:"23.9",cooktime:"20min",storeid:"741")
# Food.create(foodid:"19",name:"bull",description:"not from chicago",price:"19.99",cooktime:"20min",storeid:"741")
# Food.create(foodid:"100",name:"bee",description:"raw!!!",price:"50.0",cooktime:"20min",storeid:"741")


# Order.create(userid:"00012310",orderid:"999712",price:"54.12",EMPid:"00213441",storeid:"74162")
# Order.create(userid:"00012311",orderid:"999745",price:"11.12",EMPid:"00213421",storeid:"74146")
# Order.create(userid:"00012312",orderid:"999774",price:"20.00",EMPid:"00213436",storeid:"73416")
# Order.create(userid:"00012313",orderid:"999762",price:"30.12",EMPid:"00213485",storeid:"74116")
# Order.create(userid:"00012314",orderid:"999732",price:"29.12",EMPid:"00213456",storeid:"77416")
# Order.create(userid:"00012315",orderid:"999747",price:"14.12",EMPid:"00213474",storeid:"87416")
# Order.create(userid:"00012316",orderid:"999798",price:"54.10",EMPid:"00213491",storeid:"97416")
# Order.create(userid:"00012317",orderid:"999785",price:"54.13",EMPid:"00213482",storeid:"27416")
# Order.create(userid:"00012318",orderid:"999763",price:"54.19",EMPid:"00213493",storeid:"37416")
# Order.create(userid:"00012319",orderid:"999714",price:"4.12",EMPid:"00213471",storeid:"57416")


# Receipt.create(userid:"00012310",orderid:"974210")
# Receipt.create(userid:"00011310",orderid:"945670")
# Receipt.create(userid:"00000310",orderid:"996520")
# Receipt.create(userid:"00063310",orderid:"993210")
# Receipt.create(userid:"00074310",orderid:"991420")
# Receipt.create(userid:"00062310",orderid:"999741")
# Receipt.create(userid:"00032310",orderid:"999852")
# Receipt.create(userid:"00074310",orderid:"999963")
# Receipt.create(userid:"00095310",orderid:"999753")
# Receipt.create(userid:"00085310",orderid:"999951")
# Receipt.create(userid:"00041310",orderid:"999775")


Store.create(storeid:"74512",Name:"Mcdonald",phone:"773456789",email:"mc@mm.com",address:"123 s seed ave")
Store.create(storeid:"71422",Name:"KFC",phone:"773456789",email:"KFC@mm.com",address:"123 s fat ave")
Store.create(storeid:"85512",Name:"Subway",phone:"773456789",email:"SW@mm.com",address:"123 s slim ave")
Store.create(storeid:"96512",Name:"MingHin",phone:"773456789",email:"MH@mm.com",address:"123 e 75th ave")
Store.create(storeid:"32512",Name:"M&M",phone:"773456789",email:"mc@M&M.com",address:"123 s 12th ave")
Store.create(storeid:"62512",Name:"Gucci",phone:"773456789",email:"mc@GC.com",address:"333 s seed ave")
Store.create(storeid:"75212",Name:"BugerKing",phone:"773456789",email:"BK@mm.com",address:"1233 s seed ave")
Store.create(storeid:"74962",Name:"Stackbucks",phone:"773456789",email:"STBCK@mm.com",address:"123 s hello ave")
Store.create(storeid:"74342",Name:"Choplite",phone:"773456789",email:"CPO@mm.com",address:"123 s farm ave")
Store.create(storeid:"74742",Name:"DePaul",phone:"773456789",email:"DP@mm.com",address:"123 s kfc ave")
Store.create(storeid:"04512",Name:"CVS",phone:"773456789",email:"CVS@mm.com",address:"123 s top10 ave")


# Deliveryroute.create(beginaddress:"1323 s love st", endaddress:"6543 e woccot st", assumingtime:"2 hours", Transtime:"20 min", orderid:"123456")
# Deliveryroute.create(beginaddress:"13 s jackson st", endaddress:"7450 w lowe", assumingtime:"1 hours", Transtime:"20 min", orderid:"145126")
# Deliveryroute.create(beginaddress:"1323 s state st", endaddress:"563 s seeley st", assumingtime:"30 mins", Transtime:"20 min", orderid:"121236")
# Deliveryroute.create(beginaddress:"1 s love ave", endaddress:"7450 w state ave", assumingtime:"2 hours", Transtime:"20 min", orderid:"123456")
# Deliveryroute.create(beginaddress:"234 e clark st", endaddress:"740 w kfc ave", assumingtime:"1.5 hours", Transtime:"20 min", orderid:"147856")
# Deliveryroute.create(beginaddress:"563 s seeley st", endaddress:"450 w lowe", assumingtime:"2.5 hours", Transtime:"20 min", orderid:"123412")
# Deliveryroute.create(beginaddress:"1678 w union st", endaddress:"740 w union st", assumingtime:"0.5 hours", Transtime:"20 min", orderid:"963456")
# Deliveryroute.create(beginaddress:"9632 w hostly st", endaddress:"745 w lowe st", assumingtime:"1 hours", Transtime:"20 min", orderid:"633456")
# Deliveryroute.create(beginaddress:"6543 e woccot st", endaddress:"7441 w lowe ave", assumingtime:"2 hours", Transtime:"20 min", orderid:"623456")
# Deliveryroute.create(beginaddress:"786 w tarct st", endaddress:"9632 w hostly st", assumingtime:"2 hours", Transtime:"20 min", orderid:"363456")


# Promotion.create(title: "promotions 1", description: "promotions 1 Desc", imagepath: "samsung.png", startdate: "2019-01-01", enddate: "2019-01-31")
# Promotion.create(title: "promotions 2", description: "promotions 2 Desc", imagepath: "apple.png", startdate: "2019-02-01", enddate: "2019-02-28")
# Promotion.create(title: "promotions 3", description: "promotions 3 Desc", imagepath: "motorola.png", startdate: "2019-02-01", enddate: "2019-03-31")
# Promotion.create(title: "promotions 4", description: "promotions 4 Desc", imagepath: "acer.png", startdate: "2019-04-01", enddate: "2019-05-31")
# Promotion.create(title: "promotions 5", description: "promotions 5 Desc", imagepath: "dell.png", startdate: "2019-06-01", enddate: "2019-06-30")
