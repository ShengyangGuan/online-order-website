require 'test_helper'

class ReportControllerTest < ActionDispatch::IntegrationTest
  test "should get custlist" do
    get report_custlist_url
    assert_response :success
  end

  test "should get foodlist" do
    get report_foodlist_url
    assert_response :success
  end

  test "should get orderlist" do
    get report_orderlist_url
    assert_response :success
  end

  test "should get reportmenu" do
    get report_reportmenu_url
    assert_response :success
  end

end
