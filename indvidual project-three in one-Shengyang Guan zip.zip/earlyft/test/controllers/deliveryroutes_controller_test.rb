require 'test_helper'

class DeliveryroutesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @deliveryroute = deliveryroutes(:one)
  end

  test "should get index" do
    get deliveryroutes_url
    assert_response :success
  end

  test "should get new" do
    get new_deliveryroute_url
    assert_response :success
  end

  test "should create deliveryroute" do
    assert_difference('Deliveryroute.count') do
      post deliveryroutes_url, params: { deliveryroute: { Transtime: @deliveryroute.Transtime, assumingtime: @deliveryroute.assumingtime, beginaddress: @deliveryroute.beginaddress, endaddress: @deliveryroute.endaddress, orderid: @deliveryroute.orderid } }
    end

    assert_redirected_to deliveryroute_url(Deliveryroute.last)
  end

  test "should show deliveryroute" do
    get deliveryroute_url(@deliveryroute)
    assert_response :success
  end

  test "should get edit" do
    get edit_deliveryroute_url(@deliveryroute)
    assert_response :success
  end

  test "should update deliveryroute" do
    patch deliveryroute_url(@deliveryroute), params: { deliveryroute: { Transtime: @deliveryroute.Transtime, assumingtime: @deliveryroute.assumingtime, beginaddress: @deliveryroute.beginaddress, endaddress: @deliveryroute.endaddress, orderid: @deliveryroute.orderid } }
    assert_redirected_to deliveryroute_url(@deliveryroute)
  end

  test "should destroy deliveryroute" do
    assert_difference('Deliveryroute.count', -1) do
      delete deliveryroute_url(@deliveryroute)
    end

    assert_redirected_to deliveryroutes_url
  end
end
