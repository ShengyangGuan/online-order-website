require "application_system_test_case"

class DeliveryroutesTest < ApplicationSystemTestCase
  setup do
    @deliveryroute = deliveryroutes(:one)
  end

  test "visiting the index" do
    visit deliveryroutes_url
    assert_selector "h1", text: "Deliveryroutes"
  end

  test "creating a Deliveryroute" do
    visit deliveryroutes_url
    click_on "New Deliveryroute"

    fill_in "Transtime", with: @deliveryroute.Transtime
    fill_in "Assumingtime", with: @deliveryroute.assumingtime
    fill_in "Beginaddress", with: @deliveryroute.beginaddress
    fill_in "Endaddress", with: @deliveryroute.endaddress
    fill_in "Orderid", with: @deliveryroute.orderid
    click_on "Create Deliveryroute"

    assert_text "Deliveryroute was successfully created"
    click_on "Back"
  end

  test "updating a Deliveryroute" do
    visit deliveryroutes_url
    click_on "Edit", match: :first

    fill_in "Transtime", with: @deliveryroute.Transtime
    fill_in "Assumingtime", with: @deliveryroute.assumingtime
    fill_in "Beginaddress", with: @deliveryroute.beginaddress
    fill_in "Endaddress", with: @deliveryroute.endaddress
    fill_in "Orderid", with: @deliveryroute.orderid
    click_on "Update Deliveryroute"

    assert_text "Deliveryroute was successfully updated"
    click_on "Back"
  end

  test "destroying a Deliveryroute" do
    visit deliveryroutes_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Deliveryroute was successfully destroyed"
  end
end
