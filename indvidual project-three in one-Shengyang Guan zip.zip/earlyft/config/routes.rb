Rails.application.routes.draw do
  get 'sessions/new'
  get 'sessions/create'
  get 'sessions/destroy'
  resources :promotions
  resources :advertisements
  get 'report/custlist'
  get 'report/foodlist'
  get 'report/orderlist'
  get 'report/reportmenu'
  get 'home/catalog'  
    get 'home/search'
    post 'home/search'
  
      get 'home/askname'
  post 'home/askname'
    
    resources :stores
  resources :foods
  resources :deliveryroutes
  resources :receipts
  resources :customers
  resources :orders
  resources :employees
  get 'home/index'
  get 'home/about'
  get 'home/contact'
    get 'home/help'
    get 'home/privacy'
    
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
get 'login', to: 'sessions#new', as: 'login'
delete 'logout', to: 'sessions#destroy', as: 'logout'  
resources :sessions

    post 'home/buy'
  post 'home/updatecart'
  post 'home/checkout'
  get 'cart', to: 'home#cart', as: 'cart'

    root 'home#index'



end
