class ReportController < ApplicationController
  def custlist
  @custdata = Customer.order('lastname')
  end

  def foodlist
      @fooddata = Food.order('price')
  end

  def orderlist
  @orderdata = Order.order('orderid')
  end

  def reportmenu
  end
end
