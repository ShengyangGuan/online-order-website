class HomeController < ApplicationController
  skip_before_action :authorize

    def index
  @time = Time.now
	@ads = Promotion.where("startdate <= ? AND enddate >= ?",  Date.today, Date.today)
  end

  def about
  end

  def contact
  end
      
    def help
    end
      
    def privacy
    end
      
    def askname
	@customername = params["username"]
    end
    
    def search
    @searchinput = params["searchinput"]
	
	# Setting results flag to 0 indicate that user has not provide search criteria
	@results = 0
	
	if !@searchinput.nil? 
		if !@searchinput.empty? 
			@results = 1
			@searchresults = Food.where("description like ?", "%" + @searchinput.to_s + "%")
		end
	end
    end

    def promotions
    end

    def catalog
	@prod = Food.all
    end

def cart
end

    def buy
    # Get the specific product selected to be purchased and the quantity.
	# Converting the value to integer using the to_i method
	@prodid = params[:prodid].to_i;
	@qty = params[:qty].to_i;
	
	# Set session cart arrays to nil. 
	session[:cart_prod] << @prodid
	session[:cart_qty] << @qty

	# Redirect to display cart (shopping cart)
	redirect_to cart_url
  end

    def updatecart
 	# Get the specific item that needs to be removed
	cartid = params[:cartid].to_i;
  
	 # Remove the specific element that is desired to be removed from the array.
	session[:cart_prod].delete_at(cartid)
	session[:cart_qty].delete_at(cartid)
  
  	# Redirect to display cart (shopping cart)
	redirect_to cart_url
 end

def checkout
 	cartlen = session[:cart_prod].length
	i=0
	if cartlen > 0
	 # Save new record in Transaction table
	 # Customer ID, Sale Date and Sale Notes
	 foodid = Food.create(foodid: session[:foodid])
	# For each item in the shopping cart save the record in the in OrderItem table
	while i < cartlen
Order.create(userid: foodid.id, price: Food.find(session[:cart_prod][i].to_i).price)
		i = i + 1
	end 
  	# Set session cart arrays to nil. 
	  session[:cart_prod] = Array.new
	  session[:cart_qty] = Array.new
	end
end


end
