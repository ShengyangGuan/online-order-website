class DeliveryroutesController < ApplicationController
  before_action :set_deliveryroute, only: [:show, :edit, :update, :destroy]

  # GET /deliveryroutes
  # GET /deliveryroutes.json
  def index
    @deliveryroutes = Deliveryroute.all
  end

  # GET /deliveryroutes/1
  # GET /deliveryroutes/1.json
  def show
  end

  # GET /deliveryroutes/new
  def new
    @deliveryroute = Deliveryroute.new
  end

  # GET /deliveryroutes/1/edit
  def edit
  end

  # POST /deliveryroutes
  # POST /deliveryroutes.json
  def create
    @deliveryroute = Deliveryroute.new(deliveryroute_params)

    respond_to do |format|
      if @deliveryroute.save
        format.html { redirect_to @deliveryroute, notice: 'Deliveryroute was successfully created.' }
        format.json { render :show, status: :created, location: @deliveryroute }
      else
        format.html { render :new }
        format.json { render json: @deliveryroute.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /deliveryroutes/1
  # PATCH/PUT /deliveryroutes/1.json
  def update
    respond_to do |format|
      if @deliveryroute.update(deliveryroute_params)
        format.html { redirect_to @deliveryroute, notice: 'Deliveryroute was successfully updated.' }
        format.json { render :show, status: :ok, location: @deliveryroute }
      else
        format.html { render :edit }
        format.json { render json: @deliveryroute.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /deliveryroutes/1
  # DELETE /deliveryroutes/1.json
  def destroy
    @deliveryroute.destroy
    respond_to do |format|
      format.html { redirect_to deliveryroutes_url, notice: 'Deliveryroute was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_deliveryroute
      @deliveryroute = Deliveryroute.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def deliveryroute_params
      params.require(:deliveryroute).permit(:beginaddress, :endaddress, :assumingtime, :Transtime, :orderid)
    end
end
