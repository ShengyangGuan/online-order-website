class Order < ApplicationRecord
validates:userid, presence:true
    validates:orderid, presence:true
    validates:storeid, presence:true
    validates:EMPid, presence:true
    
    belongs_to :customer
end
