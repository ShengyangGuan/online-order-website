class Food < ApplicationRecord
validates:foodid, presence:true
    validates:name, presence:true
    validates:storeid, presence:true
    validates:price, presence:true
   
    
    belongs_to :store
end
