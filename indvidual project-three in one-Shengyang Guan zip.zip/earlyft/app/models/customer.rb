class Customer < ApplicationRecord
    validates :firstname, presence:true
    validates :lastname, presence:true
    validates :userid, presence:true
    validates :address1, presence:true
    validates :city, presence:true
    validates :state, presence:true
    
    validates :username, presence:true, uniqueness:true
	has_secure_password

    
    has_many :order, dependent: :destroy
    has_many :receipt
    
end
