class Deliveryroute < ApplicationRecord
validates:beginaddress, presence:true
validates:endaddress, presence:true
    validates:orderid, presence:true
end
