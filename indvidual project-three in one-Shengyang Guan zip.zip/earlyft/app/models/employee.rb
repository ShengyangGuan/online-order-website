class Employee < ApplicationRecord
validates:firstname, presence:true
    validates:lastname, presence:true
    validates:EMPid, presence:true
end
