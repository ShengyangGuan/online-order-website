class Store < ApplicationRecord
validates:Name, presence:true
    validates:address, presence:true
    validates:storeid, presence:true
    
    
    has_many :food
end
