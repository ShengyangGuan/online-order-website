class Receipt < ApplicationRecord
validates:userid, presence:true
    validates:orderid, presence:true
   
    belongs_to :customer
end
