module PromotionsHelper
end
