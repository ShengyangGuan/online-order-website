module ReceiptsHelper
end
